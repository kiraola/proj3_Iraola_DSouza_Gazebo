Project 3 Phase-2 
By: Kyle Iraola and Chris Neil D Souza

Steps to follow:
1) Download the package "turtlebot3_simulations" from github link provided.
2) In the case where you already have the "turtlebot3_simulations" and "turtlebot3_gazebo" folders on your machine, you must go into the downloaded package and do the following: navigate to catkin_ws->src->turtlebot3_simulations->turtlebot3_gazebo->launch, then copy the launch file "turtlebot3_AStar.launch" into your own launch file folder for turtlebot3_gazebo. Also, navigate to catkin_ws->src->turtlebot3_simulations->turtlebot3_gazebo->src and copy the "AStar.py" file into your respective src folder in turtlebot3_gazebo.
3) Run "roslaunch turtlebot3_gazebo turtlebot3_AStar.launch" in a terminal.
4) In a separate terminal, navigate to the src folder containing the AStar.py file and then run "python AStar.py" in the terminal.
5) The robot should begin moving. Due to the physics simulator and ending velocities of the robot if you choose to replay this, the path may be inconsistent.

Gazebo and Python Video is provided on the github zip.

Note:

If you want to test a new path you will have to go to the Part 1 submission and change the user speeds and clearance. Then the output list "path" from that code in the command line is to be copied and overwritten with the one in AStar.py. Save it and run it again. Unless you want to modify the launch file, use coordinates (700,50) and 150 deg starting angle for the robot.
