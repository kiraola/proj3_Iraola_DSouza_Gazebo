import pygame as pg
from collections import deque
from collision import Vector, Poly, Circle, collide
import numpy as np
import math
import sys
#import keyboard
from uuid import uuid4

v = Vector
#Function to check whether the robot at x,y coordinates is hitting an obstacle

#Determines if robot has reached the goal area    
def isGoal(euclidianDist):
    if euclidianDist < 1.5*clearRadius:
        return True
    else:
        return False
def getClearance():
    clearance = float(input("Please choose a clearance for the robot between obstacles (cm):"))
    return clearance
    
def userInputs():
    xBound = range(0,1000)
    yBound = range(0,1000)
    #Start
    startX = int(input("Enter starting X coordinate:"))
    while True:
        if startX in xBound:
            break
        else:
            startX = int(input("OUT OF BOUNDS! Please choose an X between 0 and 1000.\nEnter starting X coordinate:"))
            continue

    startY = int(input("Enter starting Y coordinate:"))
    while True:
        if startY in yBound:
            break
        else:
            startY = int(input("OUT OF BOUNDS! Please choose a Y between 0 and 1000.\nEnter starting X coordinate:"))
            continue
        
    startAngle = int(input("Enter starting angle (increments of 30" + chr(176) + "):"))
    while True:
        if (startAngle % 30) == 0 and startAngle != 360:
            break 
        else:
            startAngle = int(input("INVALID ANGLE! Please choose an angle in increments of 30" + chr(176) + ":"))
    
    if obstacle(startX, startY, clearRadius) == True:
        sys.exit("Chosen Start Node is in obstacle space. Please restart.")
    
    #Goal
    goalX = int(input("Enter goal X coordinate:"))
    while True:
        if goalX in xBound:
            break
        else:
            goalX = int(input("OUT OF BOUNDS! Please choose an X between 0 and 1000.\nEnter starting X coordinate:"))
            continue

    goalY = int(input("Enter goal Y coordinate:"))
    while True:
        if goalY in yBound:
            break
        else:
            goalY = int(input("OUT OF BOUNDS! Please choose a Y between 0 and 1000.\nEnter starting Y coordinate:"))
            continue
        
    if obstacle(goalX, goalY, clearRadius) == True:
        sys.exit("Chosen Goal Node is in obstacle space. Please restart.")
        
    speed1 = int(input("Enter a robot wheel speed (Rad/s):"))
    speed2 = int(input("Enter another robot wheel speed (Rad/s):"))
    while speed1 == speed2:
        print("Cannot choose the same speed twice.\n")
        speed2 = int(input("Please enter a different speed than " + str(speed1) + ":"))
        break
    
    
    return startX, startY, startAngle, goalX, goalY, speed1, speed2
def obstacle(x, y, clearRadius):
    robot = Circle(v(x,y), clearRadius)
    #Collision module will return true if robot is touching the obstacles
    if collide(robot, circle1) or collide(robot, circle2) or collide(robot, rect1) or collide(robot, rect2) or collide(robot, rect3):
        return True    
    elif x <= clearRadius or x>= 1000-clearRadius or y <= clearRadius or y >= 1000-clearRadius: #Checks to see if robot is within map bounds
        return True
    else:
        return False
    
def move(action, node, goalNode): 
    #node structure: {(total cost, id, parent id, (theta, x, y), [action], c2c) : (arc points)}
    #accessing node: min(dict.items()){([0][0],[0][1],[0][2],([0][3][0],[0][3][1],[0][3][2]),[0][4],[0][5]):([1][i][j],[1][ii][jj],...)}
    UL = action[0] #first element in action corresponds to left wheel speed in RPM
    UR = action[1] #second element in action corresponds to right wheel speed in RPM
    c2c = min(node.items())[0][5] #cost to come to the parent node, add the action cost to this to make the c2c of the current node
    parent = min(node.items())[0][1]
    t = 0 #initialize time
    r = 3.3 #33mm robot wheel radius -> 3.3cm
    L = 16 #160mm robot wheel distance -> 16cm
    dt = 0.1 #time step 0.1s
    Xn = min(node.items())[0][3][1] #Xn is the new X distance, will incriment with loops via time step
    Yn = min(node.items())[0][3][2] #Yn is the new Y distance, will incriment with loops via time step
    theta = min(node.items())[0][3][0]
    Thetan = (math.pi * theta / 180)
    D = 0
    curvePoints = []
    curvePoints.append((round(Xn,2),round(Yn,2)))
    
    while t < 0.5: # iterates 5 time steps. Will draw a curve by creating 10 waypoints. Last waypoint are the new coordinates post-action
        t = t + dt #time counter
        Delta_Xn = 0.5*r * (UL + UR) * math.cos(Thetan) * dt #The change in x position for each iteration of time step
        Xn = Xn + Delta_Xn
        Delta_Yn = 0.5*r * (UL + UR) * math.sin(Thetan) * dt #The change in y position for each iteration of time step
        Yn = Yn + Delta_Yn
        Thetan += (r / L) * (UR - UL) * dt #The new angle after each iteration of time step
        D = D + math.sqrt(math.pow(Delta_Xn,2)+math.pow(Delta_Yn,2))
        curvePoints.append((round(Xn,2),round(Yn,2)))   
    Thetan = round(180*(Thetan)/math.pi, 2) #converting theta back to degrees
    #Normalizing the angle to be positive, from 0-360:
    if Thetan >= 360:
        Thetan = Thetan % 360
    if Thetan < 0:
        Thetan = 360 + Thetan
    newCoord = (Thetan, Xn, Yn) #Uses final Xn and Yn and theta after all time step iterations for an action as new coordinates
    
    c2g = costToGo(Xn, Yn, goalNode)*3 #Calculates cost to go using the new X Y coordinates after an action. Weighted by 1.1x 
    #print(action)
    #print(c2c)
    #print(D)
    #print(c2g)
    newc2c = c2c + D
    newCost = c2c + D + c2g # total current cost to come (c2c of parent node + D) + cost to go
    #print(newCost)
    #print("\n")
    newNode = ((newCost, c2g), str(uuid4()), parent, newCoord, (action, Thetan), newc2c)
    return newNode, curvePoints

def getChildren(actionSet, node, goalNode,clearRadius): #Function that generates valid (non-obstacle colliding) childten
    children = {} #Dictionary for storing newly generated children with their arcs
    for action in actionSet:
        newNode, curvePoints = move(action, node, goalNode) #Unwrapping the move function into variables
        children.update({newNode:curvePoints}) #Creates a list of new children, one for each action in the action set
    "Maybe a print statement before and after children manipulation?"
    #print(len(children))
    badChildren = []
    for child in children:
        if obstacle(child[3][1], child[3][2],clearRadius) == True: #Checks each new child for being in obstacle space at the child's coordinates
            badChildren.append(child)
    #print(len(badChildren))
    for badChild in badChildren:
        children.pop(badChild) #Removes the children who are in obstacles out of the dictionary
    #print(len(children))
    #print('\n')
    return children

def isChildInOpenList(childCoordinates, openList):
    for i in range(len(openList)):
        if list(openList)[i][3] == childCoordinates:
            return True, i
    return False, None

def costToGo(Xn, Yn, goalNode):
    xGoal = goalNode[0]
    yGoal = goalNode[1]
    euclidianDist = round(math.sqrt((Xn - xGoal)**2 + (Yn - yGoal)**2), 3)
    return euclidianDist
    
def AStar(actionSet,costMatrix,openList,closedList,duplicateNodeMatrix,exploredNodes,startNode,goalNode,clearRadius):
    goal = False
    while goal == False:
        #print(len(openList))
        #print("\n")
        minItem = list(openList.items())[0] #Gets the first item from the open list, as a tuple
        #print(minItem)
        #print("\n")
        minKey = minItem[0]
        node = dict([minItem]) #reformatting into node
        openList.pop(minKey)
        #print(len(openList))
        #print("\n\n\n")
        closedList.append(node)
        duplicateNodeMatrix[round(min(node.items())[0][3][0]),round(min(node.items())[0][3][2]),round(min(node.items())[0][3][1])] = 1
        if isGoal(costToGo(min(node.items())[0][3][1],min(node.items())[0][3][2],goalNode)) == True: #Convoluted way of accessing coordinates within the node (dictionary)
            print("----------------------------------------------------------------------------------\n"
                  + "                 G   O   A   L      F   O   U   N   D   ! ! ! ! !    \n"
                  + "----------------------------------------------------------------------------------\n")
            #return True
            goal = True
            return backtrack(node, closedList, exploredNodes, openList, startNode, goalNode)
        children = getChildren(actionSet, node, goalNode, clearRadius) #Children is a dictionary
        for child in children:
            cost, index, parentIndex, coordinate, childAction, c2c = child #unwraps the variables from the tuple key in the child dictionary
            if duplicateNodeMatrix[round(child[3][0]),round(child[3][2]),round(child[3][1])] != 1: #check if child is NOT a duplucate node by checking the matrix
                exists, i = isChildInOpenList(coordinate, openList)
                if not exists and costMatrix[round(coordinate[0]),round(coordinate[2]),round(coordinate[1])] == float("inf"):
                    costMatrix[round(coordinate[0]),round(coordinate[2]),round(coordinate[1])] = cost[0]
                    openList.update({child:children[child]}) #Adding child w/ child's arc in the open list dictionary
                    openList = dict(sorted(openList.items())) #Sorting dictionary by cost (first element in each node)
                    #print(openList.items()
                    #print('\n\n\n')
                    exploredNodes.append({child:children[child]})
                else:
                    if costMatrix[round(coordinate[0]),round(coordinate[2]),round(coordinate[1])] > cost[0] and exists == True:
                        openList = list(openList.items()) #converting to list so that element i can be accessed
                        openList[i] = (child,children[child])
                        openList = dict(openList)
                        openList = dict(sorted(openList.items()))
                        exploredNodes.append({child:children[child]})
    return False


def backtrack(node, closedList, exploredNodes, openList, startNode, goalNode):
    #Example Node structure: {(cost, id, parentID, node coordinates, action, c2c) : ((0,0),(1,1),(2,2),(3,3),(4,4),...)}
    path = deque([])
    pg.init() #Drawing map in pygame
    surface=pg.display.set_mode((1000,1000))
    color=(255,0,0) #Red
    pg.draw.circle(surface, (0,255,0), goalNode, 1.5*clearRadius) #Goal is drawn as a green circle
    pg.draw.circle(surface, color, (200, 200), 100)
    pg.draw.circle(surface, color, (200, 800), 100)
    pg.draw.rect(surface, color, pg.Rect(100-75, 500-75, 150, 150))
    pg.draw.rect(surface, color, pg.Rect(500-125, 500-75, 250, 150))
    pg.draw.rect(surface, color, pg.Rect(800-75, 700-100, 150, 200))
    pg.display.flip()
    for element in range(len(exploredNodes)):
        for i in range(0,5): #Iterating through the nodes and retrieving the points that make up the action path arc
            x1 = list(exploredNodes[element].items())[0][1][i][0]
            y1 = list(exploredNodes[element].items())[0][1][i][1]
            x2 = list(exploredNodes[element].items())[0][1][i+1][0]
            y2 = list(exploredNodes[element].items())[0][1][i+1][1]
            pg.draw.line(surface, (255,255,255), (x1,y1),(x2,y2)) #drawing a white line using points that make up the action arc
            pg.display.flip()
            pg.time.wait(1)
    while min(node.items())[0][3] != min(startNode.items())[0][3]:
        path.appendleft(min(node.items())[0][4]) #appending the coordinates of the current node to the path list
        for i in range(0,5): #node[1] is the list of points that make up the arc from the node's action
            x1 = list(node.items())[0][1][i][0] #accessing the x coordinate of the arc point at iterative i
            y1 = list(node.items())[0][1][i][1] #accessing the y coordinate of the arc point at iterative i
            x2 = list(node.items())[0][1][i+1][0] #accessing the x coordinate of the next arc point from iterative i
            y2 = list(node.items())[0][1][i+1][1] #accessing the y coordinate of the next arc point from iterative i
            pg.draw.line(surface, (0,0,255), (x1,y1),(x2,y2),4) #drawing a blue line using points that make up the action arc
            pg.display.flip()
            pg.time.wait(2)
        for item in range(len(closedList)):
            if min(closedList[item].items())[0][1] == min(node.items())[0][2]: #statement checking if node index of item in closed list is the same as parent of current node
                node = closedList[item]
    return list(path), openList

clearance = getClearance()

robotRadius = 10.5 #robot radius in cm
clearRadius = clearance + robotRadius
circle1 = Circle(v(200,200), 100)
circle2 = Circle(v(200,800), 100)
rect1 = Poly.from_box(v(100,500), 150, 150)
rect2 = Poly.from_box(v(500,500), 250, 150)
rect3 = Poly.from_box(v(800,700), 150, 200)

startX, startY, startAngle, goalX, goalY, speed1, speed2 = userInputs()

#startX, startY, startAngle, goalX, goalY, speed1, speed2, clearance = (700,50,150,50,950,5,10,25)

startNode = (startAngle, startX, startY)
goalNode = (goalX, goalY)
actionSet = [(0,speed1),(speed1,0),(speed1,speed1),(0,speed2),(speed2,0),(speed2,speed2),(speed1,speed2),(speed2,speed1)]

duplicateNodeMatrix = np.zeros((361,1000,1000))
costMatrix = np.empty((361,1000,1000))
costMatrix.fill(float("inf"))

#node structure: {(total cost, id, parent id, (theta, x, y), [action], c2c) : (arc points)}
startNode = {(costToGo(startX, startY, goalNode), str(uuid4()), str(uuid4()), startNode, None, 0) : None}
openList = {}
openList.update(startNode) #put the start node in the dictionary
closedList = [] #creating a closed list
exploredNodes = []



path, openList = AStar(actionSet,costMatrix,openList,closedList,duplicateNodeMatrix,exploredNodes,startNode,goalNode,clearRadius)
print(path)
f = open("path.txt", "w")
f.write(str(path))
f.close()
print("File: path.txt has been created and saved to current directory.")
#print(openList)
pg.time.wait(10000)
pg.display.quit()
pg.quit()